const songs = [
  { title: 'Bohemian Rhapsody', artist: 'Queen', year: 1975 },
  { title: 'Stairway to Heaven', artist: 'Led Zeppelin', year: 1971 },
  { title: 'Hotel California', artist: 'Eagles', year: 1977 },
  { title: 'Imagine', artist: 'John Lennon', year: 1971 },
  { title: 'Like a Rolling Stone', artist: 'Bob Dylan', year: 1965 },
  { title: 'Sweet Child O Mine', artist: 'Guns N Roses', year: 1987 },
  { title: 'Smells Like Teen Spirit', artist: 'Nirvana', year: 1991 },
  { title: 'Purple Haze', artist: 'Jimi Hendrix', year: 1967 },
  { title: 'Let It Be', artist: 'The Beatles', year: 1970 },
  { title: 'Thriller', artist: 'Michael Jackson', year: 1982 },
]